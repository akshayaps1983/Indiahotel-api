from rest_framework import serializers
from .models import Menu,Review
from django.contrib.auth.models import User
# class MenuSerializer(serializers.Serializer):
#     dish=serializers.CharField()
#     price=serializers.IntegerField()
#     rating=serializers.IntegerField()
#     category=serializers.CharField()

class MenuModelSer(serializers.ModelSerializer):
    class Meta:
        model=Menu
        fields="__all__"    
    def validate(self, attrs):
        pr=attrs.get("price")    
        if pr<0:
            raise serializers.ValidationError("price should be a non negative value")
        return attrs
class ReviewModelSer(serializers.ModelSerializer):
    class Meta:
        model=Review
        fields=["review","rating"]
    def create(self,validated_data):
        user=self.context.get("user")
        dish=self.context.get("dish")
        print(user,dish)
        return Review.objects.create(user=user,dish=dish,**validated_data)
    
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=["username","password","email"]    
    def create(self, validated_data):
        return User.objects.create_user(**validated_data)    